
package com.mycompany.atividade2;

import java.util.Scanner;


public class Potenciada {
    
    public static void main(String[] args) {
        
            Scanner leitor = new Scanner(System.in);
            
            System.out.println("Insira a base desejada");
            Integer numBase = leitor.nextInt();
            
            System.out.println("Insira a potência desejada");
            Integer numPotencia = leitor.nextInt();
            
            Integer calculo;
            Integer auxiliar;
             
            
            for (int i = 0; i <= numPotencia; i++) {
                
                calculo = numBase * numPotencia
                
            
        }
                         

        
    }
    
}
