

package com.mycompany.atividade2;

import java.util.Scanner;



public class NumerosPares {
    
     public static void main(String[] args) {
        
    Scanner leitor = new Scanner(System.in);
    
          Integer cont = 0;
         while (cont <= 40) {

             if (cont % 2==0) {
             System.out.println(cont);    
             }
             
             
         cont++;
             
         }
    
}
     
}
