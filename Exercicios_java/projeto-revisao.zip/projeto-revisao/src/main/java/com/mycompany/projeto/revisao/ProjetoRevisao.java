
package com.mycompany.projeto.revisao;

import java.util.Scanner;


//public class ProjetoRevisao {
    
  //  public static void main(String[] args) {
        
        
       // System.out.println("Enzo");
    //    System.out.println("------------------------------------");
     //     System.out.println("------------------------------------");
          
        
     //   Scanner leitorString = new Scanner(System.in);
     //    Scanner leitorNumero = new Scanner(System.in);
     //    App pula = new App();
      //   App banana = new App();
         
     //    Integer nDigitado1 = 10;
      //   Integer nDigitado2 = 20;
         
       //  Integer Resultadao = banana.sominha(nDigitado1, nDigitado2);
  
         
         
        // System.out.println("o resultado é " + Resultadao);
         
         
         
        // pula.pulaLinha();
        
        
        
     //   System.out.println("Digite seu nome");;
     // String nomeUser = leitorString.nextLine();
        
        
      //  System.out.println("Digite sua idade");
      //  Double idadeUser = leitorNumero.nextDouble();
        
        
        
       // System.out.println(String.format("Olá leitor meu nome é %s e minha idade é %.2f ", nomeUser,idadeUser));
       
          // Integer numeroSecreto = 30;
          // Integer nDigitado = leitorNumero.nextInt();
       
       
          
          
       
        
        
      //  do {            
       //     System.out.println("Acerte um numero");
        //    nDigitado = leitorNumero.nextInt();

           
      //  } while (nDigitado != numeroSecreto);
      
      
     //   Integer contador = 0;
      //  while (contador <= 11) {

            
      //      contador++;
       // }
       
      
        
        
       
     //   for (int contador = 3; contador <= 40; contador++) {
            
            
            
            
      //  }
       
       
       
       
       
       
       
       
       
        
      // System.out.println("Escolha uma opção");
       // Integer opcaoUser = leitorNumero.nextInt();
    
     /*  
        switch (opcaoUser) {
            case 1:
                System.out.println("banana");
                break;
                 case 2:
                System.out.println("ameixa");
                break;
                 case 3:
                System.out.println("abacaxi");
                break;
                 case 4:
                System.out.println("melao");
                break;
            default:
                System.out.println("opcç~ãoi invalido");
                break;
                
        }
       */
     
     
     
     
        
        
        
        
        
   // }
    
//}
