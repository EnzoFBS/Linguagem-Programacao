
package com.mycompany.projeto.revisao;

public class App {
    
    
    void pulaLinha(){
    
        System.out.println("---------------------------------");
    
    }
    
    
    
    
    Integer sominha(Integer numero1,Integer numero2){
        
        Integer resultado = numero1 + numero2;
            
        
         return resultado;
        
    }
    
    
    
    
    
    
}
